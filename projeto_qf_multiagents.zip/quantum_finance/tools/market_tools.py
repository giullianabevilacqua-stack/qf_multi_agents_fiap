"""
Quantum Finance — Ferramentas do Market Analyst

Fontes:
  - Banco Central do Brasil (SGS API): dados macroeconômicos reais
  - Base interna: catálogo de produtos financeiros brasileiros
"""

import requests
from datetime import datetime, timedelta


# ──────────────────────────────────────────────────────────────
# Helper: Banco Central SGS API
# ──────────────────────────────────────────────────────────────

def _bcb_ultima_cotacao(serie: int) -> dict:
    """Busca a última cotação disponível na API SGS do Banco Central."""
    hoje = datetime.today()
    data_inicio = (hoje - timedelta(days=30)).strftime("%d/%m/%Y")
    data_fim = hoje.strftime("%d/%m/%Y")
    url = (
        f"https://api.bcb.gov.br/dados/serie/bcdata.sgs.{serie}/dados"
        f"?formato=json&dataInicial={data_inicio}&dataFinal={data_fim}"
    )
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        dados = resp.json()
        if dados:
            return dados[-1]
        return {"erro": "Nenhum dado retornado pela API do BCB."}
    except Exception as e:
        return {"erro": str(e)}


# ──────────────────────────────────────────────────────────────
# Tools
# ──────────────────────────────────────────────────────────────

def buscar_taxa_selic() -> dict:
    """
    Busca a Taxa Selic Meta vigente diretamente na API do Banco Central do Brasil.
    Série SGS 432.

    Returns:
        dict com 'data', 'valor' (% a.a.) e 'fonte', ou 'erro'.
    """
    dado = _bcb_ultima_cotacao(432)
    if "erro" in dado:
        return {"erro": dado["erro"], "fonte": "BCB SGS série 432"}
    return {
        "indicador": "Taxa Selic Meta",
        "valor": f"{dado.get('valor', 'N/D')}% a.a.",
        "data": dado.get("data", "N/D"),
        "fonte": "Banco Central do Brasil — SGS série 432",
    }


def buscar_ipca() -> dict:
    """
    Busca o IPCA acumulado nos últimos 12 meses diretamente na API do Banco Central.
    Série SGS 13522.

    Returns:
        dict com 'data', 'valor' (% acumulado 12m) e 'fonte', ou 'erro'.
    """
    dado = _bcb_ultima_cotacao(13522)
    if "erro" in dado:
        return {"erro": dado["erro"], "fonte": "BCB SGS série 13522"}
    return {
        "indicador": "IPCA acumulado 12 meses",
        "valor": f"{dado.get('valor', 'N/D')}%",
        "data": dado.get("data", "N/D"),
        "fonte": "Banco Central do Brasil — SGS série 13522",
    }


def buscar_cdi() -> dict:
    """
    Busca a taxa CDI diária (anualizada) diretamente na API do Banco Central.
    Série SGS 12.

    Returns:
        dict com 'data', 'valor' (% a.a.) e 'fonte', ou 'erro'.
    """
    dado = _bcb_ultima_cotacao(12)
    if "erro" in dado:
        return {"erro": dado["erro"], "fonte": "BCB SGS série 12"}
    return {
        "indicador": "Taxa CDI",
        "valor": f"{dado.get('valor', 'N/D')}% a.a.",
        "data": dado.get("data", "N/D"),
        "fonte": "Banco Central do Brasil — SGS série 12",
    }


def explicar_produto_financeiro(produto: str) -> dict:
    """
    Retorna características, riscos e tributação de produtos financeiros brasileiros.

    Args:
        produto: Nome do produto. Aceita: 'cdb', 'tesouro', 'fii', 'lci', 'lca', 'poupanca'.

    Returns:
        dict com descrição completa do produto.
    """
    catalogo = {
        "cdb": {
            "nome": "CDB — Certificado de Depósito Bancário",
            "descricao": (
                "Título de renda fixa emitido por bancos. O investidor empresta dinheiro "
                "ao banco e recebe juros em troca."
            ),
            "rentabilidade": "Geralmente indexado ao CDI (ex: 100% a 120% do CDI) ou prefixado.",
            "liquidez": "Varia: pode ter liquidez diária ou apenas no vencimento.",
            "garantia": "Coberto pelo FGC até R$ 250.000 por CPF/instituição.",
            "tributacao": (
                "Imposto de Renda regressivo: 22,5% (até 180 dias), 20% (181–360 dias), "
                "17,5% (361–720 dias), 15% (acima de 720 dias). IOF nos primeiros 30 dias."
            ),
            "perfil_indicado": "Conservador a Moderado.",
            "vantagens": ["Segurança (FGC)", "Rentabilidade acima da poupança", "Variedade de prazos"],
            "desvantagens": ["IR sobre rendimentos", "Liquidez pode ser baixa dependendo do produto"],
        },
        "tesouro": {
            "nome": "Tesouro Direto",
            "descricao": (
                "Programa do Tesouro Nacional para compra de títulos públicos federais "
                "por pessoas físicas via internet."
            ),
            "rentabilidade": (
                "Tesouro Selic: acompanha a Selic. "
                "Tesouro IPCA+: inflação + taxa prefixada. "
                "Tesouro Prefixado: taxa fixa acordada na compra."
            ),
            "liquidez": "Alta — títulos podem ser resgatados a qualquer dia útil pelo Tesouro Nacional.",
            "garantia": "Garantia do Governo Federal (risco soberano — o mais seguro do mercado).",
            "tributacao": (
                "Imposto de Renda regressivo (igual ao CDB). "
                "Taxa de custódia B3: 0,20% a.a. sobre o valor dos títulos."
            ),
            "perfil_indicado": "Conservador a Moderado.",
            "vantagens": ["Máxima segurança", "Acessível a partir de ~R$ 30", "Liquidez diária"],
            "desvantagens": ["IR sobre rendimentos", "Taxa de custódia B3", "Marcação a mercado pode gerar perdas no resgate antecipado"],
        },
        "fii": {
            "nome": "FII — Fundo de Investimento Imobiliário",
            "descricao": (
                "Fundo que investe em imóveis (shoppings, galpões logísticos, lajes corporativas, hospitais) "
                "ou papéis imobiliários (CRI, LCI). Cotas negociadas na B3 como ações."
            ),
            "rentabilidade": "Distribuição mensal de rendimentos (Dividend Yield) + valorização das cotas.",
            "liquidez": "Alta — cotas negociadas diariamente na B3.",
            "garantia": "Sem cobertura do FGC. Risco de mercado e risco do setor imobiliário.",
            "tributacao": (
                "Rendimentos mensais: isentos de IR para pessoa física (quando distribuídos por fundos "
                "com +50 cotistas e cotas negociadas em bolsa). "
                "Ganho de capital na venda das cotas: 20% de IR."
            ),
            "perfil_indicado": "Moderado a Arrojado.",
            "vantagens": ["Renda passiva mensal", "Isenção de IR nos rendimentos", "Diversificação imobiliária com baixo capital"],
            "desvantagens": ["Oscilação de mercado", "Risco de vacância", "Sem FGC"],
        },
        "lci": {
            "nome": "LCI — Letra de Crédito Imobiliário",
            "descricao": (
                "Título de renda fixa emitido por bancos, lastreado em créditos imobiliários. "
                "Recursos captados financiam o setor imobiliário."
            ),
            "rentabilidade": "Indexada ao CDI (ex: 85% a 100% do CDI) ou prefixada.",
            "liquidez": "Geralmente sem liquidez antes do vencimento (carência mínima de 9 meses).",
            "garantia": "Coberta pelo FGC até R$ 250.000 por CPF/instituição.",
            "tributacao": "ISENTA de Imposto de Renda para pessoa física — grande vantagem fiscal.",
            "perfil_indicado": "Conservador a Moderado.",
            "vantagens": ["Isenção total de IR", "Cobertura do FGC", "Rentabilidade competitiva"],
            "desvantagens": ["Liquidez baixa (carência)", "Rentabilidade nominal menor que CDB (compensada pela isenção)"],
        },
        "lca": {
            "nome": "LCA — Letra de Crédito do Agronegócio",
            "descricao": (
                "Título de renda fixa emitido por bancos, lastreado em créditos do agronegócio. "
                "Funciona de forma similar à LCI, com recursos destinados ao setor agrícola."
            ),
            "rentabilidade": "Indexada ao CDI (ex: 85% a 100% do CDI) ou prefixada.",
            "liquidez": "Sem liquidez antes do vencimento (carência mínima de 9 meses).",
            "garantia": "Coberta pelo FGC até R$ 250.000 por CPF/instituição.",
            "tributacao": "ISENTA de Imposto de Renda para pessoa física.",
            "perfil_indicado": "Conservador a Moderado.",
            "vantagens": ["Isenção total de IR", "Cobertura do FGC", "Suporte ao agronegócio brasileiro"],
            "desvantagens": ["Liquidez baixa (carência)", "Disponível em menos instituições que LCI"],
        },
        "poupanca": {
            "nome": "Poupança",
            "descricao": (
                "Investimento mais tradicional e popular do Brasil. "
                "Mantido em conta poupança em bancos."
            ),
            "rentabilidade": (
                "Quando Selic > 8,5% a.a.: 0,5% a.m. + TR. "
                "Quando Selic <= 8,5% a.a.: 70% da Selic + TR."
            ),
            "liquidez": "Alta — disponível a qualquer momento (rendimento creditado mensalmente na data de aniversário).",
            "garantia": "Coberta pelo FGC até R$ 250.000 por CPF/instituição.",
            "tributacao": "ISENTA de Imposto de Renda para pessoa física.",
            "perfil_indicado": "Conservador (reserva de emergência de curtíssimo prazo).",
            "vantagens": ["Simplicidade", "Isenção de IR", "Liquidez imediata", "FGC"],
            "desvantagens": ["Rentabilidade abaixo do CDI e do Tesouro Selic", "Não recomendada como investimento principal"],
        },
    }

    chave = produto.lower().strip()
    # Aceitar variações comuns
    if "tesouro" in chave or "selic" in chave or "ipca" in chave or "prefixado" in chave:
        chave = "tesouro"
    elif "poupan" in chave:
        chave = "poupanca"

    if chave in catalogo:
        return catalogo[chave]
    else:
        disponiveis = list(catalogo.keys())
        return {
            "erro": f"Produto '{produto}' não encontrado.",
            "produtos_disponiveis": disponiveis,
            "dica": "Tente: 'cdb', 'tesouro', 'fii', 'lci', 'lca' ou 'poupanca'.",
        }


def classificar_perfil_investidor(risco: str, prazo: str, objetivo: str) -> dict:
    """
    Classifica o perfil do investidor e sugere alocação de portfólio.

    Args:
        risco: Tolerância a risco — 'baixa', 'média' ou 'alta'.
        prazo: Prazo do investimento — 'curto' (< 2 anos), 'médio' (2–5 anos) ou 'longo' (> 5 anos).
        objetivo: Objetivo financeiro (ex: 'aposentadoria', 'reserva de emergência', 'renda passiva').

    Returns:
        dict com perfil classificado, descrição e alocação sugerida.
    """
    risco_norm = risco.lower().strip()
    prazo_norm = prazo.lower().strip()

    # Mapeamento de prazo textual
    if any(p in prazo_norm for p in ["curto", "1", "2", "emergência", "emergencia"]):
        prazo_tipo = "curto"
    elif any(p in prazo_norm for p in ["médio", "medio", "3", "4", "5"]):
        prazo_tipo = "medio"
    else:
        prazo_tipo = "longo"

    # Classificação do perfil
    if risco_norm in ("baixa", "baixo", "conservador"):
        perfil = "Conservador"
        descricao = (
            "Prioriza segurança e preservação do capital. "
            "Prefere investimentos previsíveis mesmo com rentabilidade menor. "
            "Não tolera perdas, mesmo que temporárias."
        )
        if prazo_tipo == "curto":
            alocacao = {
                "Tesouro Selic": "40%",
                "CDB liquidez diária": "30%",
                "Poupança (reserva emergência)": "20%",
                "LCI/LCA curto prazo": "10%",
            }
        else:
            alocacao = {
                "Tesouro IPCA+": "35%",
                "LCI/LCA": "30%",
                "CDB longo prazo": "25%",
                "Tesouro Selic (liquidez)": "10%",
            }

    elif risco_norm in ("média", "media", "médio", "medio", "moderado"):
        perfil = "Moderado"
        descricao = (
            "Aceita alguma oscilação em troca de maior rentabilidade no longo prazo. "
            "Combina renda fixa com renda variável de forma equilibrada. "
            "Foco em crescimento patrimonial com risco controlado."
        )
        if prazo_tipo == "curto":
            alocacao = {
                "Renda Fixa (CDB/LCI/LCA)": "60%",
                "Tesouro Selic": "20%",
                "FIIs": "15%",
                "Ações brasileiras": "5%",
            }
        elif prazo_tipo == "medio":
            alocacao = {
                "Renda Fixa (Tesouro IPCA+/LCI)": "50%",
                "FIIs": "25%",
                "Ações brasileiras (ETFs)": "20%",
                "Caixa/Liquidez": "5%",
            }
        else:
            alocacao = {
                "Renda Fixa": "40%",
                "FIIs": "30%",
                "Ações brasileiras": "25%",
                "Fundos de ações": "5%",
            }

    else:  # alta / arrojado
        perfil = "Arrojado"
        descricao = (
            "Busca maximizar rentabilidade no longo prazo. "
            "Aceita volatilidade e possíveis perdas temporárias. "
            "Foco em crescimento acelerado do patrimônio."
        )
        if prazo_tipo == "curto":
            alocacao = {
                "Renda Fixa (liquidez)": "40%",
                "Ações brasileiras": "35%",
                "FIIs": "20%",
                "Fundos multimercado": "5%",
            }
        else:
            alocacao = {
                "Ações brasileiras": "45%",
                "FIIs": "25%",
                "Renda Fixa (proteção)": "20%",
                "Fundos multimercado/internacionais": "10%",
            }

    return {
        "perfil": perfil,
        "descricao": descricao,
        "tolerancia_risco": risco,
        "prazo": prazo,
        "objetivo": objetivo,
        "alocacao_sugerida": alocacao,
        "observacao": (
            "Esta classificação é educativa. A alocação final deve considerar "
            "o cenário macroeconômico atual e as particularidades do cliente."
        ),
    }
