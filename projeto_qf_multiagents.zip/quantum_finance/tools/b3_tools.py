"""
Quantum Finance — Ferramentas do B3 Data Agent

Fontes:
  - Bolsai API (dados oficiais B3) — fonte primária
  - yfinance — fallback com delay de ~15 minutos
"""

import os
import requests
from datetime import datetime

# Tenta carregar dotenv; ignora se não instalado
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BOLSAI_API_KEY = os.getenv("BOLSAI_API_KEY", "")
BOLSAI_BASE_URL = "https://api.bolsai.com.br"


# ──────────────────────────────────────────────────────────────
# Helper: Bolsai API
# ──────────────────────────────────────────────────────────────

def _bolsai_get(endpoint: str, params: dict = None) -> dict | None:
    """Faz requisição GET na Bolsai API. Retorna None em caso de falha."""
    if not BOLSAI_API_KEY:
        return None
    headers = {"Authorization": f"Bearer {BOLSAI_API_KEY}"}
    try:
        resp = requests.get(
            f"{BOLSAI_BASE_URL}{endpoint}",
            headers=headers,
            params=params or {},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
        return None
    except Exception:
        return None


# ──────────────────────────────────────────────────────────────
# Helper: yfinance fallback
# ──────────────────────────────────────────────────────────────

def _yfinance_cotacao(ticker: str) -> dict | None:
    """Busca cotação via yfinance. Ticker deve ter sufixo .SA para ações brasileiras."""
    try:
        import yfinance as yf
        ticker_sa = ticker.upper()
        if not ticker_sa.endswith(".SA"):
            ticker_sa = ticker_sa + ".SA"
        ativo = yf.Ticker(ticker_sa)
        info = ativo.info
        preco = info.get("currentPrice") or info.get("regularMarketPrice")
        if not preco:
            return None
        return {
            "ticker": ticker.upper(),
            "preco_atual": round(preco, 2),
            "variacao_dia_pct": round(info.get("regularMarketChangePercent", 0), 2),
            "volume": info.get("regularMarketVolume", "N/D"),
            "nome": info.get("longName", ticker.upper()),
            "moeda": "BRL",
            "fonte": "yfinance (delay ~15 minutos)",
            "horario_consulta": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            "aviso": "⚠️ Dados com delay de até 15 minutos (fonte secundária).",
        }
    except Exception:
        return None


# ──────────────────────────────────────────────────────────────
# Tools
# ──────────────────────────────────────────────────────────────

def buscar_cotacao_acao(ticker: str) -> dict:
    """
    Busca a cotação atual de uma ação ou FII negociado na B3.
    Usa Bolsai API como fonte primária; yfinance como fallback.

    Args:
        ticker: Código do ativo na B3 (ex: 'PETR4', 'VALE3', 'MXRF11').

    Returns:
        dict com preço atual, variação, volume, fonte e horário da consulta.
    """
    ticker_upper = ticker.upper().strip()

    # Tenta Bolsai primeiro
    dados_bolsai = _bolsai_get(f"/quote/{ticker_upper}")
    if dados_bolsai:
        preco = dados_bolsai.get("price") or dados_bolsai.get("last") or dados_bolsai.get("close")
        variacao = dados_bolsai.get("change_percent") or dados_bolsai.get("changePercent", 0)
        return {
            "ticker": ticker_upper,
            "preco_atual": preco,
            "variacao_dia_pct": round(float(variacao), 2) if variacao else 0,
            "volume": dados_bolsai.get("volume", "N/D"),
            "nome": dados_bolsai.get("name", ticker_upper),
            "moeda": "BRL",
            "fonte": "Bolsai API — dados oficiais B3",
            "horario_consulta": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        }

    # Fallback: yfinance
    dados_yf = _yfinance_cotacao(ticker_upper)
    if dados_yf:
        return dados_yf

    return {
        "erro": f"Não foi possível obter cotação para '{ticker_upper}'.",
        "ticker": ticker_upper,
        "sugestao": "Verifique se o ticker está correto (ex: PETR4, VALE3, MXRF11).",
    }


def buscar_indicadores_fundamentalistas(ticker: str) -> dict:
    """
    Busca indicadores fundamentalistas de uma ação ou FII na B3.
    Retorna P/L, P/VP, Dividend Yield, ROE e Margem Líquida.

    Args:
        ticker: Código do ativo (ex: 'PETR4', 'ITUB4', 'MXRF11').

    Returns:
        dict com indicadores fundamentalistas e fonte dos dados.
    """
    ticker_upper = ticker.upper().strip()

    # Tenta Bolsai primeiro
    dados_bolsai = _bolsai_get(f"/fundamentals/{ticker_upper}")
    if dados_bolsai:
        return {
            "ticker": ticker_upper,
            "pl": dados_bolsai.get("pe_ratio") or dados_bolsai.get("pl", "N/D"),
            "pvp": dados_bolsai.get("pb_ratio") or dados_bolsai.get("pvp", "N/D"),
            "dividend_yield": dados_bolsai.get("dividend_yield", "N/D"),
            "roe": dados_bolsai.get("roe", "N/D"),
            "margem_liquida": dados_bolsai.get("net_margin") or dados_bolsai.get("margem_liquida", "N/D"),
            "fonte": "Bolsai API — dados oficiais B3",
            "horario_consulta": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        }

    # Fallback: yfinance
    try:
        import yfinance as yf
        ticker_sa = ticker_upper if ticker_upper.endswith(".SA") else ticker_upper + ".SA"
        ativo = yf.Ticker(ticker_sa)
        info = ativo.info

        pl = info.get("trailingPE") or info.get("forwardPE")
        pvp = info.get("priceToBook")
        dy = info.get("dividendYield")
        roe = info.get("returnOnEquity")
        margem = info.get("profitMargins")

        return {
            "ticker": ticker_upper,
            "pl": round(pl, 2) if pl else "N/D",
            "pvp": round(pvp, 2) if pvp else "N/D",
            "dividend_yield": f"{round(dy * 100, 2)}%" if dy else "N/D",
            "roe": f"{round(roe * 100, 2)}%" if roe else "N/D",
            "margem_liquida": f"{round(margem * 100, 2)}%" if margem else "N/D",
            "fonte": "yfinance (delay ~15 minutos)",
            "horario_consulta": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            "aviso": "⚠️ Dados com delay de até 15 minutos (fonte secundária).",
        }
    except Exception as e:
        return {
            "erro": f"Não foi possível obter indicadores para '{ticker_upper}': {str(e)}",
            "ticker": ticker_upper,
        }


def buscar_top_fiis_dividend_yield(limite: int = 5) -> dict:
    """
    Retorna os FIIs com maiores Dividend Yields negociados na B3.
    Usa Bolsai API como fonte primária; lista curada via yfinance como fallback.

    Args:
        limite: Quantidade de FIIs a retornar (padrão: 5, máximo: 10).

    Returns:
        dict com lista de FIIs ordenados por Dividend Yield.
    """
    limite = min(int(limite), 10)

    # Tenta Bolsai primeiro
    dados_bolsai = _bolsai_get("/fiis/top-dividend-yield", params={"limit": limite})
    if dados_bolsai:
        return {
            "fiis": dados_bolsai.get("data") or dados_bolsai,
            "total": limite,
            "fonte": "Bolsai API — dados oficiais B3",
            "horario_consulta": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        }

    # Fallback: lista curada dos maiores FIIs + yfinance
    try:
        import yfinance as yf
        tickers_fii = [
            "MXRF11", "HGLG11", "KNRI11", "XPML11", "VISC11",
            "BCFF11", "RBRF11", "HGBS11", "IRDM11", "CPTS11",
        ]
        resultados = []
        for t in tickers_fii[:limite + 3]:  # busca alguns extras para garantir o limite
            try:
                info = yf.Ticker(f"{t}.SA").info
                dy = info.get("dividendYield")
                preco = info.get("currentPrice") or info.get("regularMarketPrice")
                if dy and preco:
                    resultados.append({
                        "ticker": t,
                        "nome": info.get("longName", t),
                        "preco": round(preco, 2),
                        "dividend_yield": f"{round(dy * 100, 2)}%",
                        "dy_valor": dy,
                    })
            except Exception:
                continue

        # Ordena por DY decrescente
        resultados.sort(key=lambda x: x.get("dy_valor", 0), reverse=True)
        for r in resultados:
            r.pop("dy_valor", None)  # remove campo auxiliar

        return {
            "fiis": resultados[:limite],
            "total": len(resultados[:limite]),
            "fonte": "yfinance (delay ~15 minutos) — lista de FIIs mais negociados",
            "horario_consulta": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            "aviso": "⚠️ Dados com delay de até 15 minutos (fonte secundária).",
        }
    except Exception as e:
        return {"erro": f"Não foi possível buscar FIIs: {str(e)}"}


def buscar_historico_precos(ticker: str, periodo: str = "3mo") -> dict:
    """
    Busca o histórico de preços de uma ação ou FII via yfinance.

    Args:
        ticker: Código do ativo (ex: 'PETR4', 'VALE3').
        periodo: Período do histórico. Opções: '1mo', '3mo', '6mo', '1y', '2y', '5y'.

    Returns:
        dict com OHLCV histórico e retorno acumulado no período.
    """
    ticker_upper = ticker.upper().strip()
    ticker_sa = ticker_upper if ticker_upper.endswith(".SA") else ticker_upper + ".SA"

    periodos_validos = ["1mo", "3mo", "6mo", "1y", "2y", "5y"]
    if periodo not in periodos_validos:
        periodo = "3mo"

    try:
        import yfinance as yf
        import pandas as pd

        ativo = yf.Ticker(ticker_sa)
        hist = ativo.history(period=periodo)

        if hist.empty:
            return {
                "erro": f"Sem dados históricos para '{ticker_upper}' no período '{periodo}'.",
                "ticker": ticker_upper,
            }

        preco_inicial = round(hist["Close"].iloc[0], 2)
        preco_final = round(hist["Close"].iloc[-1], 2)
        retorno_pct = round(((preco_final - preco_inicial) / preco_inicial) * 100, 2)
        preco_max = round(hist["Close"].max(), 2)
        preco_min = round(hist["Close"].min(), 2)

        # Últimos 5 registros para contexto
        ultimos = hist.tail(5)[["Close", "Volume"]].copy()
        ultimos.index = ultimos.index.strftime("%d/%m/%Y")
        historico_recente = [
            {"data": data, "fechamento": round(row["Close"], 2), "volume": int(row["Volume"])}
            for data, row in ultimos.iterrows()
        ]

        return {
            "ticker": ticker_upper,
            "periodo": periodo,
            "preco_inicial": preco_inicial,
            "preco_atual": preco_final,
            "preco_maximo": preco_max,
            "preco_minimo": preco_min,
            "retorno_periodo_pct": f"{retorno_pct}%",
            "historico_recente": historico_recente,
            "fonte": "yfinance (delay ~15 minutos)",
            "horario_consulta": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            "aviso": "⚠️ Dados históricos com delay de até 15 minutos.",
        }
    except Exception as e:
        return {
            "erro": f"Erro ao buscar histórico de '{ticker_upper}': {str(e)}",
            "ticker": ticker_upper,
        }
