"""
Quantum Finance — Entry point do ADK

O ADK (adk web / adk run) procura por `root_agent` neste arquivo
ao carregar o pacote `quantum_finance`.
"""

from quantum_finance.agents.lead_advisor import lead_advisor_agent

root_agent = lead_advisor_agent
